package com.example.enzo.test;


import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;


public class CameraPreview extends AppCompatActivity implements SurfaceHolder.Callback, SensorEventListener{
    private SurfaceHolder surfaceHolder, transparentHolder;
    private SurfaceView surfaceView, transparentView;
    private Canvas cav;
    private Camera camera;
    private Paint paint;

    public static final int REQUEST_CAMERA = 1242;

    private SensorManager sensorManager;
    private Sensor gravity;

    private int windowWidth;
    private int windowHeight;
    private int waiting = 10;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate (Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.camera);

        // View for the camera.
        surfaceView = findViewById(R.id.preview);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceView.setSecure(true);

        // View used to draw a line over the camera.
        transparentView = findViewById(R.id.transparent);
        transparentHolder = transparentView.getHolder();
        transparentHolder.addCallback(this);
        transparentHolder.setFormat(PixelFormat.TRANSLUCENT);
        transparentView.setZOrderMediaOverlay(true);

        // Getting the gravity sensor.
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            gravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        }

        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.parseColor("green"));
        paint.setStrokeWidth(5);
        windowWidth = this.getResources().getDisplayMetrics().widthPixels;
        windowHeight = this.getResources().getDisplayMetrics().heightPixels;
    }

    // When the activity start we check if we have the permission  to use the camera,
    // and request it if it's not the case.
    @Override
    protected void onStart() {
        super.onStart();
        if (ActivityCompat.checkSelfPermission(CameraPreview.this,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(CameraPreview.this,
                    new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
        }
    }

    // Set a listener on the gravity sensor.
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, gravity, SensorManager.SENSOR_DELAY_NORMAL);
    }

    // Take off the listener of the gravity sensor.
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    // When the surface for the camera is ready we start to display the camera preview.
    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        camera = Camera.open();
        Camera.Parameters parameters = camera.getParameters();
        parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
        camera.setParameters(parameters);
        try {
            camera.setPreviewDisplay(this.surfaceHolder);
            camera.startPreview();
            camera.setDisplayOrientation(90);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        try {
            camera.stopPreview();
        } catch (Exception e){

        }
        try {
            camera.setPreviewDisplay(this.surfaceHolder);
            camera.startPreview();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        try{
            camera.stopPreview();
            camera.release();
        }catch (Exception e){

        }
    }

    // Function used to draw the line over the camera.
    public void draw(float degrees){
        cav = transparentHolder.lockCanvas();
        if (cav != null) {
            int save = cav.save();
            cav.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
            cav.rotate(degrees, windowWidth/2, windowHeight/2);
            cav.drawLine(-windowHeight, windowHeight/2, windowHeight, windowHeight/2, paint);
            cav.restoreToCount(save);
            transparentHolder.unlockCanvasAndPost(cav);
        }
    }

    // When the value of the gravity sensor change we redraw the line.
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY){

            // We draw one out of five times because the value of the sensor change very often
            // and the application crash if we draw for each change.
            if (waiting >= 5) {
                float degree = sensorEvent.values[0]*10;
                if (degree > 90) degree = 90;
                else if (degree < -90) degree = -90;
                draw(degree);
                waiting = 0;
            }
            waiting ++;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
