package fr.ancyen.maps.PackageDAO.PackageConnectionDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDatabase {
    // sert à la connexion à la base de données h2 via driver jdbc

    // singleton

    // on ne laisse pas la connexion ouverte, on recré un ppol de connexion à chaque fois
    // qu'on veut accéder à la base de données

    private static String url = "jdbc:h2:tcp://localhost/~/maps";
    private static String user = "sa";
    private static String password = "";

    private static Connection connect = null;


    public static Connection getInstance(){
        if (connect == null) {
            try {
                connect = DriverManager.getConnection(url, user, password);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return connect;
    }


}
