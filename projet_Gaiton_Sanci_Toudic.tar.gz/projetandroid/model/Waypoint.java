package fr.masterdapm.ancyen.model;

import java.io.Serializable;

/**
 * Created by cyril on 25/11/17.
 */

public class Waypoint extends Position implements Serializable{
    // reprend la structure de la classe position en ajoutant une description
    // classe utilisée pour représenter un lieu remarquable
    private String description;

    public Waypoint(double longitude, double latitude, double elevation, String description) {
        super(longitude, latitude, elevation);
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
