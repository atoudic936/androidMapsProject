package fr.masterdapm.ancyen.model;

import java.io.Serializable;

/**
 * Created by cyril on 25/11/17.
 */

public class TimedPosition extends Position implements Serializable{
    // reprend la structure de la classe position en ajoutant un temps
    // classe utilisée pour enregistrer les positions des utilstisateurs durant
    // un evenement
    // le temps permet de calculer des statistiques comme la vitesse moyenne, ...
    private String time;

    public TimedPosition(double longitude, double latitude, double elevation, String time) {
        super(longitude, latitude, elevation);
        this.time = time;
    }

    public String getTime() {
        return time;
    }

}
