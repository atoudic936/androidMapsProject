package fr.ancyen.maps;


import java.io.*;
import java.net.*;


public class MaConnexion implements Runnable {

    // pour chaque connexion, une instance de cette classe est créée
    // pour intercepter les messages du client
    // et pour lui en envoyer

    private Socket client;
    private Facade facade;

    public MaConnexion(Socket client, Facade facade) {

        this.client = client;
        this.facade = facade;

        new Thread(this).start();
    }


    public void run() {

        boolean running = true;
        try {

            ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());

            while (running) {


                // on switch en fonction du premier string
                String s = (String) ois.readObject();

                if (s.equals("checkUser")) {
                    String email = (String) ois.readObject();
                    String password = (String) ois.readObject();
                    oos.writeObject(1);

                } else if (s.equals("addUser")) {
                    facade.addUser(ois);

                } else if (s.equals("addRide")) {
                    facade.addRide(ois);

                } else if (s.equals("addStatistics")) {
                    facade.addStatistics(ois);

                } else if (s.equals("getStatisticsWithEmail")) {
                    facade.gatStatisticsWithEmail(ois, oos);

                } else if (s.equals("getRidesWithEmail")) {
                    facade.getRidesWithEmail(ois, oos);

                } else if (s.equals("getRide")) {
                    facade.getRide(ois, oos);

                } else if (s.equals("updateStatistics")) {
                    facade.updateStatistics(ois);

                } else if (s.equals("close")) {
                    running= false;
                }
            }

        } catch (IOException e) {
            running = false;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();}

        stop();
    }

    public void stop() {


        try {
            System.out.println("Connexion fermée: " + client.getRemoteSocketAddress());
            client.close();
        } catch (IOException e) {
            System.out.println("Exception a la fermeture d'une connexion"+e);
        }

    }
}
